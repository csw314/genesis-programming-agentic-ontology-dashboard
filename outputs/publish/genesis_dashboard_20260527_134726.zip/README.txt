Genesis Mission Funding and Collaboration Dashboard

Open genesis_dashboard_20260527_134726.html in a modern web browser.

This HTML dashboard is self-contained. Team members do not need Python, the
Programming Ontology repository, or access to the local data/processed folder to
view it.

Snapshot:
Generated from Programming Ontology data snapshot on 2026-05-27 13:47

Recommended sharing workflow:
1. Publish the dashboard.
2. Upload genesis_dashboard_20260527_134726.html or this zip bundle to the team-accessible location.
3. Replace the shared latest copy whenever the underlying programming artifacts
   are refreshed.
