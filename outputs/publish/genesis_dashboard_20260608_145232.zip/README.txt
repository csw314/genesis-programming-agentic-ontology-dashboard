Genesis Mission Funding and Collaboration Dashboard

Open genesis_dashboard_20260608_145232.html in a modern web browser.

This HTML dashboard is self-contained. Team members do not need Python, the
Programming Ontology repository, or access to the local data/processed folder to
view it.

Snapshot:
Generated from Programming Ontology data snapshot on 2026-06-08 14:52

Recommended sharing workflow:
1. Publish the dashboard.
2. Upload genesis_dashboard_20260608_145232.html or this zip bundle to the team-accessible location.
3. Replace the shared latest copy whenever the underlying programming artifacts
   are refreshed.
